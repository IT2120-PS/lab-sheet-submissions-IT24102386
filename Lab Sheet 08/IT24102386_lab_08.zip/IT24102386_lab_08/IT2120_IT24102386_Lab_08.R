setwd("C:/Users/USER/Desktop/IT24102386_lab_08")
data<-read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)
#Question 01
colnames(data)[1] <-"weights"
weights <- data$weights
#population mean
popmn <- mean(weights)
popmn
#population variance
popvar <- sum((weighted.mean(weights))^2) / length(weights)
popvar
pop_sd
pop_sd
#population standard deviation
pop_sd <- sqrt(popvar)
pop_sd
#Question 02
set.seed(123)
sample <- 25
n <- 6
sample_means <- numeric(samples)
#Question 02
set.seed(123)
samples <- 25
n <- 6
sample_means <- numeric(samples)
samples_sds <- numeric(samples)
for (i in 1:samples){
  s <- sample(weight, n,replace=TRUE)
  sample_means[i] <- mean(s)
  samples_sds[i] <- sd(s)
}
for (i in 1:samples){
  s <- sample(weights, n,replace=TRUE)
  sample_means[i] <- mean(s)
  samples_sds[i] <- sd(s)
}
print(sample_means)
print(samples_sds)
#Question 3
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)
print(mean_of_sample_means)
print(sd_of_sample_means)
